#include<iostream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<climits>
#include <chrono>





int fibo1(int x)
{


   if((x==1)||(x==0))
   {
      return(x);
   }
   else
   {
      return(fibo1(x-1)+fibo1(x-2));
   }



}



int fibo2(int n)
{
int fibo;
fibo=(1.0/sqrt(5))*((pow(2.0/(sqrt(5)-1),n)-(pow((-2.0/(sqrt(5)+1)),n))));
return fibo;
}

int fibo3(int n){
  static std::vector<int> w;

  if(n<=w.size())
    return w[n];

  for (int i =w.size();i<=n;i++)
    w.push_back(fibo1(i));

  return w[n];

}




int main()
{

    auto start = std::chrono::high_resolution_clock::now();
   for(int n=0;n<=48;n++)
   {
    std::cout<<"fibo 1 : "<<fibo1(n)<<std::endl<<std::endl;
   }
    auto stop = std::chrono::high_resolution_clock::now();
    auto wynik = start-stop;
    std::cout<<"fibo1 czas : "<<wynik.count();

    auto start1 = std::chrono::high_resolution_clock::now();
   for(int n=0;n<=48;n++)
   {
    std::cout<<"fibo 2 : "<<fibo2(n)<<std::endl<<std::endl;
   }
    auto stop1 = std::chrono::high_resolution_clock::now();
    auto wynik1 = start1-stop1;
    std::cout<<"fibo1 czas : "<<wynik1.count();


   auto start2 = std::chrono::high_resolution_clock::now();
   for(int n=0;n<=48;n++)
   {
    std::cout<<"fibo 3 : "<<fibo3(n)<<std::endl<<std::endl;
   }
   auto stop2 = std::chrono::high_resolution_clock::now();
    auto wynik2 = start-stop;
    std::cout<<"fibo1 czas : "<<wynik2.count();

return 0;
}
