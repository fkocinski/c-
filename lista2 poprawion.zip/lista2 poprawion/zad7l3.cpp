#include <iostream>
#include <cmath>

int nwd(int x, int y) {
    if (x == 0 or y == 0) 
        return -1;

    x = std::abs(x);
    y = std::abs(y);

    while (x != y) {
        if (x > y)
            x -= y;
        else
            y -= x;
    }
    return x;
}

int main() {
    std::cout << nwd(25, 15) << "\n";

    return 0;
}
/*nie moze byc and musi byc or aby  program sie nie zapetlil