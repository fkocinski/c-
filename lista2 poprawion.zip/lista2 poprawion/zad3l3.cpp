#include <iostream>
#include <vector>
#include <climits>

double operator*(const std::vector<double>& w1,const std::vector<double>& w2)
{
    if(w1.size()!=w2.size())
    {
        std::cout << "Wektory mają różne rozmiary !" << std::endl;
        return 0;
    }
    double wynik=0;
    for(unsigned int i = 0; i<w1.size();i++)
    {
        wynik += w1[i] * w2[i];
    }
    return wynik;
}

int main()
{

    std::vector<double> v{4,3};
    std::vector<double> w{5,5};
    std::vector<double> a{4,3};
    std::vector<double> b{3,5,5};
    double test = v * w;
    std::cout << test << std::endl;
    double test1 = a * b;
    std::cout << test1 << std::endl;


    return 0;
}
