#include<iostream>
#include<vector>
#include<algorithm>
#include<climits>

int zeruj(std::vector<double>& wektor)
{

    std::fill(wektor.begin(), wektor.end(), 0);
    return 0;
}

int main()
{
    std::vector<double> wektor1={3.456,5.62626,6.123213,1.1231,8.3};
    std::vector<double> wektor2={3.89};
    std::cout<<zeruj(wektor1)<<std::endl;
    std::cout<<zeruj(wektor2)<<std::endl;

return 0;
}