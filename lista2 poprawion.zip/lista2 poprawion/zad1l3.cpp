#include<iostream>
#include<vector>
#include<algorithm>
#include<climits>

int najmniejszy(const std::vector<int>& wektor)
{
if(wektor.size()==0)
    return INT_MIN;
else
    return *std::min_element(wektor.begin(),wektor.end());
}

int main()
{
    std::vector<int> wektor1={3,5,6,1,8};
    std::vector<int> wektor2;
    std::cout<<najmniejszy(wektor1)<<std::endl;
    std::cout<<najmniejszy(wektor2)<<std::endl;

return 0;
}
