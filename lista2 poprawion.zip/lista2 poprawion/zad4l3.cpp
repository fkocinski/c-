#include <iostream>
unsigned silnia(unsigned n)
{
    if(n==0)
        return 1;
    else
        return n * silnia(n-1);
}
int main()
{
    for(int i=-1;i<5;i++)
        std::cout << i << "!=" << silnia(i) << "\n";
}

/*przy uruchomianiu programu wyświetla się komunikat :: naruszenie ochrony pamięci
kiedy zapisujemy unsigned nie ma ostatniego bitu , który określa czy liczba jest ujemna czy dodatnia
ponieważ z góry zakładamy że nie ma przy sobie znaku(jest dodatnia).Testowalem podoby program ktory mial tylko wypisac 
typ unsigned i przypisana do niego liczbe ujemna , program bez znaczenia jak mala czy duza to liczba ujemna zwraca duza liczbe*/