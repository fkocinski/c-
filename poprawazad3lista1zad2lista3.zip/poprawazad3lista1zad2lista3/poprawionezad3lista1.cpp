#include <iostream>
#include <cmath>
#include <math.h>
using namespace std;

long double a(int i){
    if (i==0)
        return 1/sqrt(3);
    else
        return sqrt(pow(a(i-1),2)+1)-1/a(i-1);
}

long double b(int i){
    if (i==0)
        return 1/sqrt(3);
    else
        return b(i-1)/(sqrt(pow(b(i-1),2)+1)+1) ;
}

int main(){

    long double pi;
    cout<<"Wzor a\n";
    for(int i=0;i<=10;i++){
        pi = 6*pow(2,i)*a(i);
        cout<<"Określone PI: "<<pi;
        cout<<" Roznica: "<<M_PI-pi<<endl;
    }

    cout<<"\nWzor b\n";
    for(int i=0;i<=10;i++){
        pi = 6*pow(2,i)*b(i);
        cout<<"Okreslone PI: "<<pi;
        cout<<" Roznica: "<<M_PI-pi<<endl;
    }


    return 0;
}
