#include <iostream>
#include <vector>

void funk(int*&wsk);


int main()
{
   
    double(*t)[100];  //punkt 1
	
	char* tab[5][5];      //punkt 2
	
	char*x[]={};           //punkt 
	char**z;
	
	std::vector<void*> y; //punkt 4
	
	std::vector<double>p[4];  //punkt 5
	
	double(*fpointer) (double [], int);  //punkt 6

	
}


