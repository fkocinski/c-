#include <iostream>

class Samochod
{
int _kola;
/*zmienne statyczne nalezy inicjalizowac globalnie nawet gdy są prywatne*/
/*1 sposób to przerzucenie części prywatnej kodu nad publiczną oraz zamiana miejsc 
int_kola oraz int_sruby natomiast 2 sposob to zamiast _sruby(4*_kola) dac _sruby(4*n)*/
private:
    int _kola;
    int _sruby;
public:
    Samochod (int n)
    : _kola (n), _sruby (4*_kola)
    {
        std::cout << "Samochod z " << _kola <<  " kolami i "
  	          << _sruby << " srubami\n";
    }

};

int main()
{
    Samochod s4 (4);
    Samochod s12 (12);
}

