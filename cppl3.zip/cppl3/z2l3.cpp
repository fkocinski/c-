#include <iostream>
#include <vector>


int main()
{
   
    double(*t)[100];  //punkt 1
	
	char* tab[5][5];      //punkt 2
	
	char*x[]={};           //punkt 
	char**z;
	
	std::vector<void*> x; //punkt 4
	
	std::vector<double>t[4];  //punkt 5
	
	double(*fpointer) (double [], int);  //punkt 6

	void(*fp) (int) = &z;
	fp = &f;
	

}


