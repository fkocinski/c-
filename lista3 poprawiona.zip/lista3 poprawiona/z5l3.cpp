#include <iostream>
#include <cstring>

int main()
{
    char tmp[8];
    char haslo[8];
    strcpy(haslo,"Ta.jnE!");
    for ( ; ;)
    {
        std::cout <<"podaj haslo: ";
        std::cin >> tmp;
        if (strcmp(tmp,haslo)==0)
            break;
        std::cout<<"przykro mi, haslo jest niepoprawne!\n";

    }
    std::cout << "witaj w systemie!\n";
}
/*Dzia�anie programu jest w du�ym stopniu uzale�nione od systemu , z za�o�enia gdy nikt tego
nie sprawdzi gdy zostanie wpisane np 12 znakow do tablicy o rozmiarze 8 to wszystko to
co poza tym okreslonym rozmiarem moze zostac przypisane do tej zmiennej , dlatego gdy 8 miejsc
zajely liczby 12345678 zmienna zostala nadpisana reszta hasla czyli 12345678*/
