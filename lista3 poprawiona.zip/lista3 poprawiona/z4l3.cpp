 
#include <iostream>

int main()
{
    double tab[10];
    double y;
    double x;
    x=10;
    std::cout << &x << "\t" << &tab[-1] << "\n";
    //Adres listy jest rowny adresowi pierwszego obiektu , w przypadku tym podaje adres z pamieci ostatniego obiektu
    std::cout << &y << "\t" << &tab[-2] << "\n";
    //w tym przypadku podaje adres w pamięci przedostatnio obiektu
    //niepoprawne indeksowanie tabic przyniesie nam problemy z korzystaniem z adsresow
    
}