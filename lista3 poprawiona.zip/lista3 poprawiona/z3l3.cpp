
#include <iostream>
#include <ctime>
#include <list>
int main()
{
    unsigned N = 8500000; //dla takiego N wykonanie petli trwa 1s
    std::clock_t start;
    start = std::clock();
    for (unsigned n=1;n<=N;++n)
    {
        int* p = new int[n];
        delete [] p;
    }
    std::cout<<( std::clock() - start ) / (double) CLOCKS_PER_SEC<<"\n";


    std::clock_t start1;
    start1 = std::clock();
    for (int n=1;n<=N;++n)
    {
        int p=5;
        int wynik;
        wynik=n+p;
    }
    std::cout<<( std::clock() - start1 ) / (double) CLOCKS_PER_SEC<<"\n";

}
